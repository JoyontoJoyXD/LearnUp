from django.apps import AppConfig


class StartupappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'startupapp'
